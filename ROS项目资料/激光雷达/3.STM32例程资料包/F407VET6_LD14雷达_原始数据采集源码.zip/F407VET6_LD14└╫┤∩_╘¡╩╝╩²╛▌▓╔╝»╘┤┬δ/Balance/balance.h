#ifndef __BALANCE_H
#define __BALANCE_H			  	 
#include "sys.h"
#include "system.h"
#define ZHONGZHI 0
void	TIM7_IRQHandler(void);
void  Find_CCD_Zhongzhi(void);

#endif  

